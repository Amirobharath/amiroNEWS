# Archive Notice

This repository is archived and is no longer being maintained. You can now build an app using our online App Studio at https://median.co/app and download custom iOS source code for free.


gonative-android
================

This is the native Android code previously used by [GoNative](https://median.co).

It allows the creation of apps from existing mobile-optimized websites.

How to use
------------
Import into Android Studio. Edit appConfig.json as appropriate.
