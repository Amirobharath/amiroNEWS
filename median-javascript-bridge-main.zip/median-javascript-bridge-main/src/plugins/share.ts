type ShareToAppData = { url: string; subject: string };

export { ShareToAppData };
